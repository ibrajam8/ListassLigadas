package linkedlist;

public class linkedListt {

    private Node head;
    private Node tail;
    private int length;

    // Clase Nodo
    class Node {
        int value;
        Node next;

        public Node(int value) {
            this.value = value;
            this.next = null;
        }
    }

    // Constructor
    public linkedListt(int value) {
        Node newNode = new Node(value);
        head = newNode;
        tail = newNode;
        length = 1;
    }

    // Mostrar Head
    public void getHead() {
        if (head != null) {
            System.out.println("Head: " + head.value);
        } else {
            System.out.println("Head: null");
        }
    }

    // Mostrar Tail
    public void getTail() {
        if (tail != null) {
            System.out.println("Tail: " + tail.value);
        } else {
            System.out.println("Tail: null");
        }
    }

    // Mostrar Length
    public void getLength() {
        System.out.println("Length: " + length);
    }

    // Agregar al final
    public void append(int value) {

        Node newNode = new Node(value);

        if (length == 0) {
            head = newNode;
            tail = newNode;
            length = 1;
            return;
        }

        tail.next = newNode;
        tail = newNode;
        length++;
    }

    // Imprimir lista
    public void printList() {

        Node temp = head;

        while (temp != null) {
            System.out.println(temp.value);
            temp = temp.next;
        }
    }

    // Eliminar último
    public Node removeLast() {

        if (length == 0) {
            return null;
        }

        Node temp = head;
        Node pre = head;

        while (temp.next != null) {
            pre = temp;
            temp = temp.next;
        }

        tail = pre;
        tail.next = null;

        length--;

        if (length == 0) {
            head = null;
            tail = null;
        }

        return temp;
    }

    // Eliminar primero
    public Node removeFirst() {

        if (length == 0) {
            return null;
        }

        Node temp = head;

        if (length == 1) {
            head = null;
            tail = null;
        } else {
            head = head.next;
            temp.next = null;
        }

        length--;

        return temp;
    }

    // Obtener nodo por índice
    public Node get(int index) {

        if (index < 0 || index >= length) {
            return null;
        }

        Node temp = head;

        for (int i = 0; i < index; i++) {
            temp = temp.next;
        }

        return temp;
    }


    // INSERT
   

    public boolean insert(int index, int value) {

        // Índice fuera de rango
        if (index < 0 || index > length) {
            return false;
        }

        // Insertar al inicio
        if (index == 0) {

            Node newNode = new Node(value);

            if (length == 0) {
                head = newNode;
                tail = newNode;
            } else {
                newNode.next = head;
                head = newNode;
            }

            length++;
            return true;
        }

        // Insertar al final
        if (index == length) {
            append(value);
            return true;
        }

        // Insertar en medio
        Node newNode = new Node(value);
        Node temp = get(index - 1);

        newNode.next = temp.next;
        temp.next = newNode;

        length++;

        return true;
    }
    // REMOVE

    public Node remove(int index) {

        // Índice inválido
        if (index < 0 || index >= length) {
            return null;
        }

        // Eliminar primero
        if (index == 0) {
            return removeFirst();
        }

        // Eliminar último
        if (index == length - 1) {
            return removeLast();
        }

        // Eliminar nodo del medio
        Node previous = get(index - 1);
        Node temp = previous.next;

        previous.next = temp.next;
        temp.next = null;

        length--;

        return temp;
    }

    // REVERSE

    public void reverse() {

        Node temp = head;

        head = tail;
        tail = temp;

        Node before = null;
        Node after;

        while (temp != null) {

            after = temp.next;
            temp.next = before;

            before = temp;
            temp = after;
        }
    }

    // =========================================================
    // NODO MEDIO
    // =========================================================

    public Node medio() {

        if (head == null) {
            return null;
        }

        Node temp1 = head;
        Node tem2 = head;

        while (tem2 != null && tem2.next != null) {

            temp1 = temp1.next;
            tem2 = tem2.next.next;
        }

        return temp1;
    }

    // DETECTAR CICLO

    public boolean ciclo() {

        Node tem1 = head;
        Node tem2 = head;

        while (tem2 != null && tem2.next != null) {

            tem1 = tem1.next;
            tem2 = tem2.next.next;

            if (tem1 == tem2) {
                return true;
            }
        }

        return false;
    }
}