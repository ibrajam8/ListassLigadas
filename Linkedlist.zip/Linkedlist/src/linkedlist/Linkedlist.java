package linkedlist;

public class Linkedlist {

    public static void main(String[] args) {
        linkedListt ll=new linkedListt(10);
        ll.append(20);
        ll.append(30);
        ll.append(40);
        ll.append(50);
        ll.printList();
        System.out.println("DATOS ADICIONALES");
        ll.getHead();
        ll.getTail();
        ll.getLength();
        System.out.println("Probando REMOVE 50");
        System.out.println( ll.removeLast().value );
                System.out.println("Probando REMOVE 40");
        System.out.println( ll.removeLast().value );
                System.out.println("Probando REMOVE 30");
        System.out.println( ll.removeLast().value );
                System.out.println("Probando REMOVE 20");
        System.out.println( ll.removeLast().value );
                System.out.println("Probando REMOVE 10");
        System.out.println( ll.removeLast().value );
        System.out.println("Probando REMOVE vacio");
        System.out.println( ll.removeLast() );
        ll.append(100);
        System.out.println("IMPRIME LISTA CON 100");
        ll.printList();
        System.out.println("IMPRIME LISTA CON mas numeros");
        ll.append(200);
        ll.printList();
        System.out.println("Buscar el nodo 2");
        ll.get(1);
        System.out.println("QUITAR EL PRIMERO EH IMPRIMIR LA CABEZA ACTUAL");
        ll.removeFirst();
        ll.printList();
        System.out.println("PROBRAR CON 1 NODO (ELIMINARLO)");
        System.out.println( ll.removeFirst() );
    }
    
}
